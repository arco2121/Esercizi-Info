﻿using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Dizionatoneria.Tests
{
    [TestFixture]
    public class InventoryManagerTests
    {
        private Dictionary<int, (int, string)> inventario;

        [SetUp]
        public void SetUp()
        {
            inventario = new Dictionary<int, (int, string)>();
        }

        [Test]
        public void Aggiungi_ItemUnico_Successo()
        {
            InventoryManager.Aggiungi(inventario, 1, "Penne", 100);

            Assert.That(inventario.Count, Is.EqualTo(1));
            Assert.That(inventario[1], Is.EqualTo((100, "Penne")));
        }

        [Test]
        public void Aggiungi_IDDuplicato_LanciaEccezione()
        {
            InventoryManager.Aggiungi(inventario, 1, "Penne", 100);

            var ex = Assert.Throws<ArgumentException>(() => InventoryManager.Aggiungi(inventario, 1, "Matite", 50));
            Assert.That(ex.Message, Is.EqualTo("ID già esistente."));
        }

        [Test]
        public void Aggiorna_ItemEsistente_Successo()
        {
            InventoryManager.Aggiungi(inventario, 1, "Penne", 100);
            InventoryManager.Aggiorna(inventario, 1, "Matite", 50);

            Assert.That(inventario[1], Is.EqualTo((50, "Matite")));
        }

        [Test]
        public void Aggiorna_ItemNonEsistente_LanciaEccezione()
        {
            var ex = Assert.Throws<KeyNotFoundException>(() => InventoryManager.Aggiorna(inventario, 1, "Matite", 50));
            Assert.That(ex.Message, Is.EqualTo("ID non trovato."));
        }

        [Test]
        public void Rimuovi_ItemEsistente_Successo()
        {
            InventoryManager.Aggiungi(inventario, 1, "Penne", 100);
            InventoryManager.Rimuovi(inventario, 1);

            Assert.That(inventario.Count, Is.EqualTo(0));
        }

        [Test]
        public void Rimuovi_ItemNonEsistente_LanciaEccezione()
        {
            var ex = Assert.Throws<KeyNotFoundException>(() => InventoryManager.Rimuovi(inventario, 1));
            Assert.That(ex.Message, Is.EqualTo("ID non trovato."));
        }

        [Test]
        public void Visualizza_RitornaTuttiGliElementi()
        {
            InventoryManager.Aggiungi(inventario, 1, "Penne", 100);
            InventoryManager.Aggiungi(inventario, 2, "Matite", 50);

            var result = InventoryManager.Visualizza(inventario);

            Assert.That(result, Has.Exactly(1).EqualTo((1, "Penne", 100)));
            Assert.That(result, Has.Exactly(1).EqualTo((2, "Matite", 50)));
        }

        [Test]
        public void Ricerca_RitornaElementiCorrispondenti()
        {
            InventoryManager.Aggiungi(inventario, 1, "Penne", 100);
            InventoryManager.Aggiungi(inventario, 2, "Matite", 50);

            var result = InventoryManager.Ricerca(inventario, "Pen");

            Assert.That(result, Has.Exactly(1).EqualTo((1, "Penne", 100)));
            Assert.That(result.Count, Is.EqualTo(1));
        }

        [Test]
        public void Gestione_RitornaElementiSottoSoglia()
        {
            InventoryManager.Aggiungi(inventario, 1, "Penne", 10);
            InventoryManager.Aggiungi(inventario, 2, "Matite", 50);

            var result = InventoryManager.Gestione(inventario, 20);

            Assert.That(result, Has.Exactly(1).EqualTo((1, "Penne", 10)));
            Assert.That(result.Count, Is.EqualTo(1));
        }
    }
}