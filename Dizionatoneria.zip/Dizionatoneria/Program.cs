﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Dizionatoneria
{
    public class InventoryManager
    {
        public static void Aggiungi(Dictionary<int, (int, string)> inventario, int id, string nome, int quantita)
        {
            if (!inventario.ContainsKey(id))
            {
                inventario[id] = (quantita, nome);
            }
            else
            {
                throw new ArgumentException("ID già esistente.");
            }
        }

        public static void Aggiorna(Dictionary<int, (int, string)> inventario, int id, string nome, int quantita)
        {
            if (inventario.ContainsKey(id))
            {
                inventario[id] = (quantita, nome);
            }
            else
            {
                throw new KeyNotFoundException("ID non trovato.");
            }
        }

        public static void Rimuovi(Dictionary<int, (int, string)> inventario, int id)
        {
            if (!inventario.Remove(id))
            {
                throw new KeyNotFoundException("ID non trovato.");
            }
        }

        public static List<(int id, string nome, int quantita)> Visualizza(Dictionary<int, (int, string)> inventario)
        {
            var risultato = new List<(int id, string nome, int quantita)>();
            foreach (var elemento in inventario)
            {
                risultato.Add((elemento.Key, elemento.Value.Item2, elemento.Value.Item1));
            }
            return risultato;
        }

        public static List<(int id, string nome, int quantita)> Ricerca(Dictionary<int, (int, string)> inventario, string nome)
        {
            var risultato = new List<(int id, string nome, int quantita)>();
            foreach (var elemento in inventario)
            {
                if (elemento.Value.Item2.Contains(nome))
                {
                    risultato.Add((elemento.Key, elemento.Value.Item2, elemento.Value.Item1));
                }
            }
            return risultato;
        }

        public static List<(int id, string nome, int quantita)> Gestione(Dictionary<int, (int, string)> inventario, int soglia)
        {
            var risultato = new List<(int id, string nome, int quantita)>();
            foreach (var elemento in inventario)
            {
                if (elemento.Value.Item1 <= soglia)
                {
                    risultato.Add((elemento.Key, elemento.Value.Item2, elemento.Value.Item1));
                }
            }
            return risultato;
        }
    }

    class Program
    {
        static Dictionary<int, (int, string)> Inventariololo = new Dictionary<int, (int, string)>();

        static void Main(string[] args)
        {
            Gestisci(true);
        }

        static void Gestisci(bool chose)
        {
            while (chose)
            {
                Console.Write("\n\nScelta:\n\nAggiungi  1\nAggiorna  2\nRimuovi  3\nVisualizza  4\nRicerca  5\nGestione  6\nEsci  X\n\nScelta:");
                string choise = Console.ReadLine();
                try
                {
                    switch (choise)
                    {
                        case "1":
                            Console.Write("\nID: ");
                            int idA = int.Parse(Console.ReadLine());
                            Console.Write("\nNome: ");
                            string nomeA = Console.ReadLine();
                            Console.Write("\nQuantita: ");
                            int quantitaA = int.Parse(Console.ReadLine());
                            InventoryManager.Aggiungi(Inventariololo, idA, nomeA, quantitaA);
                            break;
                        case "2":
                            Console.Write("\nID: ");
                            int idU = int.Parse(Console.ReadLine());
                            Console.Write("\nNome: ");
                            string nomeU = Console.ReadLine();
                            Console.Write("\nQuantita: ");
                            int quantitaU = int.Parse(Console.ReadLine());
                            InventoryManager.Aggiorna(Inventariololo, idU, nomeU, quantitaU);
                            break;
                        case "3":
                            Console.Write("\nID: ");
                            int idR = int.Parse(Console.ReadLine());
                            InventoryManager.Rimuovi(Inventariololo, idR);
                            break;
                        case "4":
                            var visualizzati = InventoryManager.Visualizza(Inventariololo);
                            foreach (var item in visualizzati)
                            {
                                Console.WriteLine($"\nID: {item.id} Nome: {item.nome} Quantita: {item.quantita}");
                            }
                            break;
                        case "5":
                            Console.Write("\nNome: ");
                            string nomeRicerca = Console.ReadLine();
                            var trovati = InventoryManager.Ricerca(Inventariololo, nomeRicerca);
                            foreach (var item in trovati)
                            {
                                Console.WriteLine($"\nID: {item.id} Nome: {item.nome} Quantita: {item.quantita}");
                            }
                            break;
                        case "6":
                            Console.Write("\nQuantita soglia: ");
                            int soglia = int.Parse(Console.ReadLine());
                            var gestiti = InventoryManager.Gestione(Inventariololo, soglia);
                            foreach (var item in gestiti)
                            {
                                Console.WriteLine($"\nID: {item.id} Nome: {item.nome} Quantita: {item.quantita}");
                            }
                            break;
                        case "X":
                            chose = false;
                            break;
                        default:
                            Console.WriteLine("\nComando non valido.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"\nErrore: {ex.Message}");
                }
            }
        }
    }
}

/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Dizionatoneria
{
    internal class Program
    {
        static Dictionary<int, (int,string)> Inventariololo = new Dictionary<int, (int, string)>();
        static void Main(string[] args)
        {
            Gestisci(true);
        }

        static void Gestisci(bool chose)
        {
            while(chose)
            {
                Console.Write("\n\nScelta:\n\nAggiungi  1\nAggiorna  2\nRimuovi  3\nVisualizza  4\nRicerca  5\nGestione  6\nEsci  X\n\nScelta:");
                string choise = Console.ReadLine();
                switch(choise)
                {
                    case "1": {
                            Aggiungi();
                            break;
                        };
                    case "2": {
                            Aggiorna();
                            break;
                        };
                    case "3": {
                            Rimuovi();
                            break;
                        };
                    case "4": {
                            Visualizza();
                            break;
                        };
                    case "5": {
                            Ricerca();
                            break;
                        };
                    case "6": {
                            Gestione();
                            break;
                        };
                    case "X":
                        {
                            chose = false;
                            break;
                        }
                    default: {
                            Console.WriteLine("\nWrong command >:(");
                            break;
                        };
                }
            }
            return;
        }

        private static void Gestione()
        {
            int y = 0;
            here10:
            try
            {
                Console.Write("\nQuantita: ");
                y = Int32.Parse(Console.ReadLine());
            }
            catch
            {
                goto here10;
            }
            foreach (var t in Inventariololo)
            {
                if (t.Value.Item1 <= y)
                {
                    Console.WriteLine($"\nID : {t.Key}  Nome : {t.Value.Item2}  Quantita : {t.Value.Item1}\n");
                }
            }
            return;
        }

        private static void Ricerca()
        {
            Console.Write("\nNome : ");
            string h = Console.ReadLine();
            foreach(var t in Inventariololo)
            {
                if(t.Value.Item2.Contains(h))
                {
                    Console.WriteLine($"\nID : {t.Key}  Nome : {t.Value.Item2}  Quantita : {t.Value.Item1}\n");
                }
            }
            return;
        }

        private static void Visualizza()
        {
           foreach(var t in Inventariololo)
            {
                Console.WriteLine($"\nID : {t.Key}  Nome : {t.Value.Item2}  Quantita : {t.Value.Item1}\n");
            }
        }

        private static void Rimuovi()
        {

            int x = 0;
        here3:
            try
            {
                Console.Write("\nID: ");
                x = Int32.Parse(Console.ReadLine());
            }
            catch
            {
                goto here3;
            }
            try
            {
                Inventariololo.Remove(x);
            }
            catch
            {
                return;
            }
        }

        private static void Aggiorna()
        {
            int x = 0;
            int y = 0;
            here4:
            try
            {
                Console.Write("\nID: ");
                x = Int32.Parse(Console.ReadLine());
            }
            catch
            {
                goto here4;
            }
            try
            {
                Console.Write("\nNome : ");
                string ui = Console.ReadLine();
                here5:
                try
                {
                    Console.Write("\nQuantita: ");
                    y = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    goto here5;
                }
                Inventariololo[x] = (y, ui);
            }
            catch
            {
                return;
            }
        }

        private static void Aggiungi()
        {
            Console.Write("\nNome: ");
            string ui = Console.ReadLine();
            int x= 0;
            int y = 0;
            here:
            try
            { 
                Console.Write("\nID: ");
                x = Int32.Parse(Console.ReadLine());
            }
            catch
            {
                goto here;
            }
            here2:
            try
            {
                Console.Write("\nQuantita: ");
                y = Int32.Parse(Console.ReadLine());
            }
            catch
            {
                goto here2;
            }
            Inventariololo.Add(x, (x, ui));
        }
    }
}
*/